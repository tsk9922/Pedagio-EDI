#define MAXFILA 100

struct carro
{
	char placa[10],cor[10],fabricante[20];
	int eixos,categoria,prio,te,ts;
};

struct filac
{
	int inicio,fim;
	carro fila[MAXFILA];
};

void iniciar(filac &f)
{
	f.inicio = 0;
	f.fim = -1;
}

char cheio(int inicio,int fim)
{
	return fim-inicio == MAXFILA-1;
}

char vazio(int inicio,int fim)
{
	return inicio>fim;
}

carro inicio(filac f)
{
	return f.fila[f.inicio%MAXFILA];
}

carro fim(filac f)
{
	return f.fila[f.fim%MAXFILA];
}

void inserir(filac &f,carro c)
{
	f.fila[++f.fim%MAXFILA] = c;
}

carro retirar(filac &f)
{
	return f.fila[f.inicio++%MAXFILA];
}

void exibir(filac f)
{
	carro c;
	while(!vazio(f.inicio,f.fim))
	{
		c = retirar(f);
		if(c.categoria==1)
			printf(" [A] ");
		if(c.categoria==2)
			printf(" [B] ");
		if(c.categoria==3)
			printf(" [C] ");
	}
}
