#include <stdio.h>
#include <ctype.h>
#include <conio2.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include "fila_circ.h"

#define TF 10

void divisao()
{
	int x=0, y;
	
	for(y=3;y<21;y+=1)
	{
		if(y%2!=0)
		{
			gotoxy(1,y);
			printf("%d--------------------",x+1);
			x++;
		}
		else
		{
			gotoxy(1,y);
			printf("%c", 204);	
		}
	}
}

int min(filac f[],int v[])
{
	int min = 99999,pos;
	for(int i=0;i<TF-1;i++)
	{
		if(v[i] == 1)
		{
			if(f[i].fim-f[i].inicio+1<min)
			{
				min = f[i].fim-f[i].inicio+1;
				pos = i;
			}	
		}	
	}	
		
	return pos;
}

int main()
{
	FILE *ptr = fopen("carros.txt","r");
	
	filac fila[TF];
	carro c,c1, carro1;
	
	char tecla;
	int TL, contp=0, i, minp, tempo=0, intervalo, cont1=0, cont2=0, cont3=0, somas=0, somae=0, flag[TF], cont1p=0, cont2p=0, cont3p=0, total=0, pos =0, k, contprio=0, seq=0, z, flag1=0,j;
	float tms=0,tme=0;
	
	for(i=0;i<TF;i++)
	{
		flag[i] = 0;
		iniciar(fila[i]);
	}
		
	printf("Digite a quantia de catracas ativadas: ");
	scanf("%d",&TL);
	
	for(i=0;i<TL;i++)
	{
		flag[i] = 1;
	}
	flag[9] = 1;
	
	printf("Digite o tempo entre a chegada de carros: ");
	scanf("%d",&intervalo);
	
	do
	{
		do
		{
			system("cls");
			divisao();
			if(tempo%intervalo == 0)
			{
				if(!feof(ptr))
				{
					flag1=0;
					fscanf(ptr, "%[^;];%[^;];%[^;];%d;%d;%d;%d\n", &c.placa, &c.cor, &c.fabricante, &c.eixos, &c.categoria, &c.prio, &c.ts);
					
					c.te = tempo;
					somas+= c.ts;
					
					if(c.prio == 1)
					{
						inserir(fila[9], c);
						
						if(c.categoria == 1)
							cont1p++;
						if(c.categoria == 2)
							cont2p++;
						if(c.categoria == 3)
							cont3p++;
						
						contprio++;
					}	
					else
					{
						minp = min(fila,flag);
						
						inserir(fila[minp],c);
					}
					
					seq++;	
				}
			}
			
			for(i=0;i<TF;i++)
			{
				if(!vazio(fila[i].inicio, fila[i].fim) && fila[i].fila[fila[i].inicio%MAXFILA].ts == 0)
				{
					c1 = retirar(fila[i]);
					somae+=tempo-c1.te;
					if(c1.categoria == 1)
						cont1++;
					if(c1.categoria == 2)
						cont2++;
					if(c1.categoria == 3)
						cont3++;
					
					total++;
					tms =(float) somas/(cont1+cont2+cont3);
					tme =(float) somae/(cont1+cont2+cont3);
				}
				else
				{
					if(!vazio(fila[i].inicio,fila[i].fim))
						fila[i].fila[fila[i].inicio%MAXFILA].ts--;
				}	
			}
			
			tempo++;
			
			z=4;
			
			for(i=0;i<TF-1;i++)
			{	
				if(!vazio(fila[i].inicio, fila[i].fim))
				{
					carro1 = inicio(fila[i]);
				
					if(i==0)
					{
						gotoxy(1,i+22); 
						printf("Catraca %d -> Placa: %s | Cor: %s | Fabricante: %s | Categoria: %d", i+1, carro1.placa, carro1.cor, carro1.fabricante, carro1.categoria);
					
						gotoxy(2, z);
						exibir(fila[i]);
					}
					else
					{
						gotoxy(1,i+22); 
						printf("Catraca %d -> Placa: %s | Cor: %s | Fabricante: %s | Categoria: %d", i+1, carro1.placa, carro1.cor, carro1.fabricante, carro1.categoria);
					
						gotoxy(2, z);
						exibir(fila[i]);
					}
				}
				z+=2;
			}
			gotoxy(1,1);
			printf("Sem Parar------------"); 
			gotoxy(2,2);
			exibir(fila[9]);
			
			gotoxy(33,3);	printf("Tempo medio de espera para saida do pedagio: %.2f",tms);
			gotoxy(33,4);	printf("Tempo medio de espera em atendimento: %.2f",tme);
			
			gotoxy(33,6);	printf("Total de motos que passaram pelo pedagio: %d",cont1);
			gotoxy(33,7);	printf("Total de carros que passaram pelo pedagio: %d",cont2);
			gotoxy(33,8);	printf("Total de caminhoes que passaram pelo pedagio: %d",cont3);
			
			gotoxy(33,10);	printf("Total de motos que passaram pelo Sem Parar na ultima hora: %d",cont1p);
			gotoxy(33,11);	printf("Total de carros que passaram pelo Sem Parar na ultima hora: %d",cont2p);
			gotoxy(33,12);	printf("Total de caminhoes que passaram pelo Sem Parar na ultima hora: %d",cont3p);
			gotoxy(33,13);	printf("Total de veiculos que passaram pelo Sem Parar na ultima hora: %d", contprio);
		
			gotoxy(33,14);	printf("Total de veiculos que passaram pelo pedagio na ultima hora: %d",total);
			
			if(tempo%60 == 0)
			{
				cont1p=0;
				cont2p=0;
				cont3p=0;
				
				contprio=0;
				
				total=0;
			}	
			
			j=0;
			for(i=0;i<TF;i++)
			{
				if(vazio(fila[i].inicio,fila[i].fim))
					j++;
			}
			if(j==TF)
				flag1=1;
			
			Sleep(1000);
			
		}while(!kbhit() && (flag1==0||!feof(ptr)));
		
		tecla = getch();
		
		switch(tecla)
		{
			case '0':	if(flag[0] == 1) 
							flag[0] = 0;
						else
							flag[0] = 1;
						break;
						
			case '1':	if(flag[1] == 1)
							flag[1] = 0;
						else
							flag[1] = 1;
						break;
						
			case '2':	if(flag[2] == 1)
							flag[2] = 0;
						else
							flag[2] = 1;
						break;
						
			case '3':	if(flag[3] == 1)
							flag[3] = 0;
						else
							flag[3] = 1;
						break;
						
			case '4':	if(flag[4] == 1)
							flag[4] = 0;
						else
							flag[4] = 1;
						break;
						
			case '5':	if(flag[5] == 1)
							flag[5] = 0;
						else
							flag[5] = 1;
						break;
						
			case '6':	if(flag[6] == 1)
							flag[6] = 0;
						else
							flag[6] = 1;
						break;
						
			case '7':	if(flag[7] == 1)
							flag[7] = 0;
						else
							flag[7] = 1;
						break;
						
			case '8':	if(flag[8] == 1)
							flag[8] = 0;
						else
							flag[8] = 1;
						break;
		}
		
	}while(tecla != 27 && (flag1==0||!feof(ptr)));
	
	fclose(ptr);
}
